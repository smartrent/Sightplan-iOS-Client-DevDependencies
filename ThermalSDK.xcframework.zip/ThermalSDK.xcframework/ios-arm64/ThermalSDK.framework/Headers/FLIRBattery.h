//
//  FLIRBattery.h
//  ThermalSDK
//
//  Created by FLIR on 2020-07-02.
//  Copyright © 2020 FLIR Systems. All rights reserved.
//

/**
 ChargingState
 */
typedef NS_ENUM(NSUInteger, FLIRChargingState)
{
    /** Indicates that the battery is not charging because the camera is in "developer mode". */
    DEVELOPER,
    /**  Indicates that the battery is not charging because the camera is not connected to an external power supply. */
    NOCHARGING,
    /**  Indicates that the battery is charging from external power. */
    MANAGEDCHARGING,

    /** Indicates that the battery is charging the iPhone.

      This field indicates that IF there is an iPhone plugged in, it will
      be receiving power from the RBPDevice battery. However, it is still possible
      for the RBPDevice to be in this "mode" EVEN IF THERE IS NO IPHONE ATTACHED.
     */
    CHARGINGSMARTPHONE,

    /**  Indicates that a charging fault occurred (overheat, etc.) */
    FAULT,
    /**  Indicates that a charging heat fault occured */
    FAULTHEAT,
    /**  Indicates that a charging fault occured due to low current from the charging source */
    FAULTBADCHARGER,
    /**  Indicates that a charging fault exists but the iPhone is being charged */
    CHARGINGSMARTPHONEFAULTHEAT,
    /**  Indicates that the device is in charge-only mode */
    MANAGEDCHARGINGONLY,
    /**  Indicates that the device is in phone-charging-only mode */
    CHARGINGSMARTPHONEONLY,
    /**  Indicates that a valid battery charging state was not available. */
    BAD
};

/**
* Camera battery status monitoring interface
*/
@interface FLIRBattery : NSObject
/** Gets a battery charging state. */
- (FLIRChargingState) getChargingState;
/** Gets remaining battery power in percentage (0-100). */
- (int)getPercentage;
/** Subscribes for battery charging state notifications. */
- (BOOL)subscribeChargingState: (out NSError * _Nullable *_Nullable) error;
/** Revokes subscription for battery charging state. */
- (void)unsubscribeChargingState;
/** Subscribes for remaining battery power notifications. */
- (BOOL)subscribePercentage: (out NSError * _Nullable *_Nullable) error;
/** Revokes subscription for remaining battery power. */
- (void)unsubscribePercentage;
@end
